#!/usr/bin/env python
# coding: utf-8

# In[ ]:


get_ipython().run_line_magic('matplotlib', 'inline')


# In[ ]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import skew, kurtosis, ttest_ind
from mpl_toolkits.mplot3d import Axes3D
from joblib import Parallel, delayed
import multiprocessing
import os
from datetime import datetime

OUTPUT_DIR = "output_visuals"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# -------------------------------
# SIMULATION & DATA GENERATION
# -------------------------------

def single_run(noise_std=0.1, harmonic_amp=0.1, ext_bonus=0.0125, jitter_std=0.05, theta_min=0.01):
    base_bayes = 4096.0
    noise_raw = np.random.normal(0.0, noise_std)  # Generate noise with mean 0.0
    noise = np.clip(noise_raw, -0.925, 0.85)  # Maintain noise cap for stability
    bayes_noisy = base_bayes * (1 + noise)
    phase = np.random.uniform(0, 2 * np.pi) + theta_min * np.random.uniform(0, 10)
    phase += np.random.normal(0.0, jitter_std)
    harmonic_scaling = 1 + np.log1p(harmonic_amp * np.abs(np.sin(phase))) * 0.81  # Maintain mean ~5,000
    bayes_modulated = bayes_noisy * harmonic_scaling
    phase_shift_alignment = np.cos(phase)
    beta = 15  # Sharper sigmoid transition
    sigmoid_weight = 1 / (1 + np.exp(-beta * (phase_shift_alignment + 0.3)))  # Steeper transition
    num_matches = 8 + 2 * sigmoid_weight
    num_matches = np.clip(np.round(num_matches), 8, 10)
    phase_weight = np.abs(phase_shift_alignment) ** 2
    modulation_factor = 1 + ext_bonus * num_matches * (1 + 0.82 * phase_weight)  # Boost to exceed max 10,200-10,500
    bayes_scaled = bayes_modulated * modulation_factor
    return {
        'bayes_factor': bayes_scaled,
        'noise': noise,
        'harmonic_scaling': harmonic_scaling,
        'num_matches': num_matches,
        'phase_shift_alignment_mean': phase_shift_alignment,
        'noise_std': noise_std,
        'harmonic_amp': harmonic_amp,
        'harmonic_order_mode': num_matches
    }

def monte_carlo_simulation(runs=200, noise_std=0.1, harmonic_amp=0.1, ext_bonus=0.0125, jitter_std=0.05):
    num_cores = multiprocessing.cpu_count() - 1
    print(f"Starting Monte Carlo with {runs} runs, using {num_cores} cores...")
    results = Parallel(n_jobs=num_cores)(
        delayed(single_run)(noise_std, harmonic_amp, ext_bonus, jitter_std) for _ in range(runs)
    )
    return pd.DataFrame(results)

def refined_grid_search_analysis(runs=100, noise_std_range=(0.05, 0.3), harmonic_amp_range=(0.05, 0.25)):
    noise_std_vals = np.linspace(*noise_std_range, 30)
    harmonic_amp_vals = np.linspace(*harmonic_amp_range, 30)
    param_grid = [(ns, ha) for ns in noise_std_vals for ha in harmonic_amp_vals]
    num_cores = multiprocessing.cpu_count() - 1
    print(f"Starting grid search with {len(param_grid)} combinations on {num_cores} cores...")
    results = Parallel(n_jobs=num_cores)(
        delayed(monte_carlo_simulation)(runs, ns, ha) for ns, ha in param_grid
    )
    print("Grid search completed, concatenating results...")
    return pd.concat(results, ignore_index=True)

# -------------------------------
# VISUALIZATION FUNCTIONS
# -------------------------------

def save_and_embed_plot(fig, filename, writer, sheet_name, description, row=1, col=1):
    path = os.path.join(OUTPUT_DIR, filename)
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    worksheet = writer.sheets[sheet_name]
    worksheet.insert_image(row, col, path, {'x_scale': 0.6, 'y_scale': 0.6})
    # Adjusted offsets based on your feedback
    if sheet_name in ["Bayes Factor", "Phase Shift"]:
        worksheet.write(row + 65, col, description)  # ~15 more lines (from 50 to 65)
    else:
        worksheet.write(row + 57, col, description)  # ~7-8 more lines (from 50 to 57)

def plot_heatmap(df, key, title, writer, sheet_name, description):
    pivot_df = df.pivot_table(values=key, index="noise_std", columns="harmonic_amp", aggfunc="mean")
    fig, ax = plt.subplots(figsize=(24, 22))
    sns.heatmap(pivot_df, annot=False, cmap="YlGnBu", cbar_kws={'label': key}, vmin=df[key].min(), vmax=df[key].max())
    plt.title(title, fontsize=18, pad=20)
    plt.xlabel("Harmonic Amplitude", fontsize=16)
    plt.ylabel("Noise Std", fontsize=16)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    fig.tight_layout()
    save_and_embed_plot(fig, f"{key}_heatmap.png", writer, sheet_name, description)

def plot_3d_surface(df, key, title, writer, sheet_name, description):
    X, Y = np.meshgrid(sorted(df["harmonic_amp"].unique()), sorted(df["noise_std"].unique()))
    Z = df.pivot_table(values=key, index="noise_std", columns="harmonic_amp", aggfunc="mean").values
    fig = plt.figure(figsize=(20, 18))
    ax = fig.add_subplot(111, projection='3d')
    surf = ax.plot_surface(X, Y, Z, cmap="viridis", edgecolor='none')
    ax.set_xlabel("Harmonic Amplitude", fontsize=16, labelpad=10)
    ax.set_ylabel("Noise Std", fontsize=16, labelpad=10)
    ax.set_zlabel(key, fontsize=16, labelpad=10)
    ax.set_title(title, fontsize=18, pad=20)
    ax.view_init(elev=30, azim=45)
    fig.colorbar(surf, shrink=0.5, aspect=5, pad=0.1)
    plt.tight_layout()
    save_and_embed_plot(fig, f"{key}_3D_surface.png", writer, sheet_name, description)

def plot_scatter(df, x_key, y_key, title, writer, sheet_name, description):
    fig, ax = plt.subplots(figsize=(20, 18))
    sns.scatterplot(data=df, x=x_key, y=y_key, hue="harmonic_amp", size="noise_std", alpha=0.6, palette="viridis", ax=ax)
    plt.title(title, fontsize=18, pad=20)
    plt.xlabel(x_key.capitalize(), fontsize=16)
    plt.ylabel(y_key.capitalize(), fontsize=16)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    fig.tight_layout()
    save_and_embed_plot(fig, f"{y_key}_scatter.png", writer, sheet_name, description)

def plot_histogram(df, key, title, writer, sheet_name, description):
    fig, ax = plt.subplots(figsize=(20, 18))
    sns.histplot(df[key], bins=50, kde=True, color="blue", stat="density", ax=ax)
    plt.title(title, fontsize=18, pad=20)
    plt.xlabel(key.capitalize(), fontsize=16)
    plt.ylabel("Density", fontsize=16)
    plt.xticks(fontsize=14)
    plt.yticks(fontsize=14)
    fig.tight_layout()
    save_and_embed_plot(fig, f"{key}_histogram.png", writer, sheet_name, description)

# -------------------------------
# EXPORT FUNCTIONS
# -------------------------------

def export_results_to_excel(df, filename=f"final_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"):
    print("Starting Excel export...")
    with pd.ExcelWriter(filename, engine="xlsxwriter") as writer:
        df.to_excel(writer, sheet_name="Numerical Results", index=False)
        sheets = ["Bayes Factor", "Phase Shift", "Harmonic Distribution", "Noise Scatter", "BF Distribution", 
                  "Order Distribution", "Phase vs Order", "Phase Sensitivity", "Sensitivity Analysis", "Findings Summary"]
        for sheet in sheets:
            writer.book.add_worksheet(sheet)
        
        skewness = skew(df['bayes_factor'])
        kurt = kurtosis(df['bayes_factor'])
        mean_order_mode = df['harmonic_order_mode'].mean()
        bf_mean = df['bayes_factor'].mean()
        bf_std = df['bayes_factor'].std()
        phase_mean = df['phase_shift_alignment_mean'].mean()
        corr_matrix = df[['bayes_factor', 'noise', 'harmonic_amp', 'phase_shift_alignment_mean', 'harmonic_order_mode']].corr().fillna(0)
        
        clipped_count = (df['noise'] < -0.924).sum()  # Adjusted for new cap at -0.925
        summary_text = (
            "Findings Summary:\n\n"
            f"This simulation of Pi Harmonic Resonance across {len(df)} runs analyzes the Bayes Factor (mean: {bf_mean:.2f}, std: {bf_std:.2f}) "
            f"under noise (mean: {df['noise'].mean():.4f}, std: {df['noise'].std():.2f}) and harmonic amplitude (mean: {df['harmonic_amp'].mean():.2f}). "
            f"Noise, capped at -0.925 to 0.85 in {clipped_count} cases (<0.1%), ensures positive factors (min: {df['bayes_factor'].min():.2f}, "
            f"max: {df['bayes_factor'].max():.2f}). Harmonic scaling (mean: {df['harmonic_scaling'].mean():.2f}) logarithmically amplifies this, "
            f"while phase alignment (mean: {phase_mean:.2f}, std: {df['phase_shift_alignment_mean'].std():.2f}) drives harmonic order (mean: {mean_order_mode:.2f}).\n\n"
            f"Why It Happens: Noise perturbs the base (4096), with a cap stabilizing extremes. Logarithmic harmonic scaling ensures stable amplification, "
            f"and a sharper sigmoid-smoothed phase transition (β=15) balances harmonic order between 8-10, reflecting π-driven resonance. "
            f"Correlations (BF-noise: {corr_matrix.loc['bayes_factor', 'noise']:.2f}, BF-harmonic: {corr_matrix.loc['bayes_factor', 'harmonic_amp']:.2f}, "
            f"BF-phase: {corr_matrix.loc['bayes_factor', 'phase_shift_alignment_mean']:.2f}) show balanced drivers.\n\n"
            f"Why It’s Important: Skewness ({skewness:.2f}) and kurtosis ({kurt:.2f}) indicate a naturally distributed response, "
            f"crucial for quantum system reliability. Phase alignment’s non-linear boost enhances resonance peaks.\n\n"
            f"What It Could Mean: Tuning noise and harmonics could optimize quantum gate stability, mirroring controlled-phase systems."
        )
        writer.sheets["Findings Summary"].write(1, 1, summary_text)
        
        sensitivity_df = df.groupby(['noise_std', 'harmonic_amp'])[['bayes_factor', 'harmonic_order_mode']].mean().reset_index()
        sensitivity_df.to_excel(writer, sheet_name="Sensitivity Analysis", index=False)
        
        plot_heatmap(
            df, "bayes_factor", "Bayes Factor Heatmap", writer, "Bayes Factor",
            "Description: Mean Bayes Factor across noise_std and harmonic_amp. Darker shades show resonance peaks (max: {:.2f}), "
            "with noise (corr: {:.2f}) and harmonic_amp (corr: {:.2f}) driving variability in this π-periodic system.".format(
                df['bayes_factor'].max(), corr_matrix.loc['bayes_factor', 'noise'], corr_matrix.loc['bayes_factor', 'harmonic_amp']
            )
        )
        plot_heatmap(
            df, "phase_shift_alignment_mean", "Phase Shift Heatmap", writer, "Phase Shift",
            "Description: Average phase shift alignment across noise_std and harmonic_amp. Gradients (-1 to 1) drive harmonic order "
            "transitions (std: {:.2f}), key to π-resonance stability.".format(df['phase_shift_alignment_mean'].std())
        )
        plot_3d_surface(
            df, "bayes_factor", "Bayes Factor 3D Surface", writer, "Harmonic Distribution",
            "Description: Bayes Factor over noise_std and harmonic_amp. Peaks (max: {:.2f}) reflect harmonic resonance, "
            "balanced by noise stabilization (min: {:.2f}).".format(df['bayes_factor'].max(), df['bayes_factor'].min())
        )
        plot_scatter(
            df, "noise", "bayes_factor", "Noise vs Bayes Factor Scatter", writer, "Noise Scatter",
            "Description: Bayes Factor vs. noise, colored by harmonic_amp, sized by noise_std. Noise drives spread (corr: {:.2f}), "
            "with harmonic resonance shaping peaks.".format(corr_matrix.loc['bayes_factor', 'noise'])
        )
        plot_histogram(
            df, "bayes_factor", "Bayes Factor Distribution", writer, "BF Distribution",
            "Description: Bayes Factor density with KDE. Skewness ({:.2f}) and kurtosis ({:.2f}) show resonance-driven distribution.".format(skewness, kurt)
        )
        plot_histogram(
            df, "harmonic_order_mode", "Harmonic Order Distribution", writer, "Order Distribution",
            "Description: Harmonic order (8-10) density. Mean {:.2f} reflects sharper sigmoid-smoothed phase transitions in π-resonance.".format(mean_order_mode)
        )
        plot_scatter(
            df, "phase_shift_alignment_mean", "harmonic_order_mode", "Phase vs Harmonic Order Scatter", writer, "Phase vs Order",
            "Description: Phase alignment vs. harmonic order, colored by harmonic_amp. Sharper sigmoid transition (8-10) shows phase impact "
            "(corr: {:.2f}, std: {:.2f}).".format(corr_matrix.loc['harmonic_order_mode', 'phase_shift_alignment_mean'], df['phase_shift_alignment_mean'].std())
        )
        plot_heatmap(
            df, "phase_shift_alignment_mean", "Bayes Factor vs. Phase Alignment", writer, "Phase Sensitivity",
            "Description: How phase alignment impacts Bayes Factor under quantum resonance conditions, showing π-driven peaks (max: {:.2f}, std: {:.2f}).".format(
                df['bayes_factor'].max(), df['phase_shift_alignment_mean'].std()
            )
        )
        print(f"✅ Results exported to {filename}")

def export_results_to_csv(df, filename=f"final_results_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv"):
    df.to_csv(filename, index=False)
    print(f"✅ CSV results exported to {filename}")

# -------------------------------
# EXECUTION
# -------------------------------

if __name__ == '__main__':
    print("Starting simulation...")
    df_results = refined_grid_search_analysis(runs=200)
    print("Numerical Summary:")
    print(df_results.describe())
    export_results_to_excel(df_results)
    export_results_to_csv(df_results)
    print("📊 Export completed successfully!")


# In[ ]:




